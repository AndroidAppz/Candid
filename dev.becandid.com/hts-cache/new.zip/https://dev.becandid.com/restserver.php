<!doctype html>
<html>
    <head>
        <title>Candid</title>
        <meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no">
        <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
        <meta name="google" value="notranslate" />
        <meta http-equiv="Content-Language" content="en" />
        <link type="text/css" rel="stylesheet" href="/s/3e2562f6e73ee778c99052687eeda590/loggedout_react.css" />
        <link href="https://fonts.googleapis.com/css?family=Roboto:100, 300, 400" rel="stylesheet" type="text/css">
        <link href="https://fonts.googleapis.com/css?family=Josefin+Sans:600" rel="stylesheet" type="text/css">

                <meta property="og:url" content="https://becandid.com" />
                <meta name="twitter:url" content="https://becandid.com" />
                <meta property="og:title" content="Candid - Speak Your Mind Freely" />
                <meta name="twitter:title" content="Candid - Speak Your Mind Freely" />
                <meta property="og:image" content="https://becandid.com/images/gossip/candid-og.jpg" />
                <meta name="twitter:image" content="https://becandid.com/images/gossip/candid-og.jpg" />
                <meta property="og:description" content="Speak Your Mind Freely With The People And Communities That Matter To You" />
                <meta name="twitter:description" content="Speak Your Mind Freely With The People And Communities That Matter To You" />
                <meta name="twitter:card" content="summary_large_image" />
                <meta name="twitter:site" content="@becandidapp" />
                <meta property="fb:app_id" content="996059910461168" />
                <meta property="al:ios:app_store_id" content="991032122" />
                <meta name="twitter:app:id:iphone" content="991032122" />
                <meta property="al:ios:app_name" content="Candid" />
                <meta name="twitter:app:name:iphone" content="Candid" />
                <meta property="al:ios:url" content="https://itunes.apple.com/us/app/candid-speak-your-mind-freely/id991032122?ls=1&amp;mt=8" />
                <meta name="twitter:app:url:iphone" content="https://itunes.apple.com/us/app/candid-speak-your-mind-freely/id991032122?ls=1&amp;mt=8" />
                <meta property="al:android:package" content="com.becandid.candid" />
                <meta name="twitter:app:id:googleplay" content="com.becandid.candid" />
                <meta property="al:android:app_name" content="Candid" />
                <meta name="twitter:app:name:googleplay" content="Candid" />
                <meta property="al:android:url" content="https://play.google.com/store/apps/details?id=com.becandid.candid" />
                <meta name="twitter:app:url:googleplay" content="https://play.google.com/store/apps/details?id=com.becandid.candid" />

<style>
#header {
    background-color:transparent;
    border:none;
}
#thepage {
    padding-top:0;
}
.phone_inner .scrollable {
    animation: feedscroll 50s linear infinite;
    position:absolute;
    left:0px;
    right:0px;
    top:0px;
    width:100%;
}
.scrollable img {
    width:100%;
    display:block;
}
@keyframes feedscroll {
    0% { top:5%; }
    100% { top:-416%; }
}
@-moz-keyframes feedscroll {
    0% { top:5%; }
    100% { top:-416%; }
}
@-webkit-keyframes feedscroll {
    0% { top:5%; }
    100% { top:-416%; }
}
</style>


        <div id="header" class="  ">
          <div class="main_content">
                    <a href='/'><div class="tab logo"><div class="c_logo logo2"></div></div></a>
                    <a href='/about'><div class="tab r">About</div></a>
                    <a href='http://blog.becandid.com'><div class="tab r">Blog</div></a>
            </div>
        </div>
    </head>
    <body >
        <div id="thepage" class=" ">

<script src="/dist/main.b431d0be714554e906f4.js"></script>

<div id="fb-root"></div>
<div id="homepage_slider" class="page_slider">

    <div class="page_contents">
        <div id="page_0" class="slider_page">
            <div class="slider_contents">
                <div class="phone_col_top">
                    <h1>Candid - Speak Your Mind Freely</h1>
                    <h2><a href="https://blog.becandid.com/candid-and-free-speech-e23a03cb09f1">Candid and Free Speech</a></h2>
                    <table cellpadding="0" cellspacing="0" border="0" style="margin: 0 auto;">
                        <tr>
                            <td style="vertical-align: top;">
                              <a class="button blue_button signup" id="login_fb_button" href="javascript:;">
                                  <img class="fb_logo" src="/images/likes/fb-logo.png">
                                  <span class="text">&nbsp;Sign Up With Facebook</span><div class='spinny'><img style='width:15px; height:15px;' src='/images/gossip/spinny-150.gif' /></div>
</span>
                              </a>
                              <div class="fb-error"></div>
                            </td>
                            <td style="vertical-align: top;">
                              <div style="margin: 12px 13px 0 12px; color: white; font-size: 16px;">OR</div>
                            </td>
                            <td style="vertical-align: top;">
                                <div class="mobile_app_upsell phone_number_input">
                                    <div class="button_input c_blue">
                                        <div class="button spinny_button send_login_code" style="font-size: 16px;">Sign Up With Phone<div class='spinny'><img style='width:15px; height:15px;' src='/images/gossip/spinny-150.gif' /></div>
</div>
                                        <div class="bi_input">
                                            <input type='text' class='phone_input' />
                                        </div>
                                    </div>
                                    <div class="bottom_text"></div>
                                </div>
                                <div class="clear"></div>
                                <div  class="mobile_app_upsell confirmation_code_input">
                                    <div class="button_input c_blue">
                                        <div class="button spinny_button send_confirmation_code">Log in<div class='spinny'><img style='width:15px; height:15px;' src='/images/gossip/spinny-150.gif' /></div>
</div>
                                        <div class="bi_input">
                                            <input type='text' class='confirmation_input' placeholder="Confirmation Code" />
                                        </div>

                                    </div>
                                    <div class="bottom_text" style="color: #3a6f74;"></div>
                                </div>
                                <div class="clear"></div>
                            </td>
                        </tr>
                    </table>
                    <div class="clear"></div>
                    <div class="accepting_terms">By signing up, you're accepting our <a href="/terms">Terms of Service</a>.</div>
                    <div class="app_buttons">    <a class='app_download_button floatleft' href='https://itunes.apple.com/us/app/candid-speak-your-mind-freely/id991032122?ls=1&amp;mt=8'>
        <img src='/images/gossip/download_ios.png'>
    </a>
    <a class='app_download_button floatright' href='https://play.google.com/store/apps/details?id=com.becandid.candid'>
        <img src='/images/gossip/download_android.png'>
    </a>

</div>
                </div>
                <div class="phone_col">
                    <div class="phone">
                        <div class="phone_container">
                            <img class='phone_container_img' src='/images/gossip/iphone_frame.png' />
                            <div class="phone_inner">
                                <img class="phone_header" src='/images/gossip/main_header2.jpg'>
                                <img class="phone_footer" src='/images/gossip/main_nav2.png'>
                                <div class='scrollable'>
                                    <img src='/images/gossip/candid-feed-2.jpg' />
                                    <img src='/images/gossip/candid-feed-2.jpg' />
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div
        ><div id="page_1" class="slider_page">
            <div class="slider_contents">
                <h1>Personalized communities tailored to your interests</h2>
                <div class="animation">
<div id="gl"><a href='/g/'  class="group" data-group_id="">
    <div class="group_photo" style="background-image:url(https://s.mlv-cdn.com/gossip/7220aee4f9c6cf4a0a19f028eabb4616.600x);"></div>
    <div class="group_overlay"></div>
    <div class="group_name">Fails and Funny Stories</div>
    <div class="group_info">
        <div class="row stats">
<div class="stat">28 friends</div>            <div class="stat">1,920 members</div>
            <div class="stat">102 posts</div>
        </div>
        <div class="row tags"><div class="tag">funny</div><div class="tag">entertainment</div></div>
        <div class="row about">It&#39;s always funny until someone gets hurt</div>
    </div>
</a>
</div><div id="gr"><a href='/g/'  class="group" data-group_id="">
    <div class="group_photo" style="background-image:url(/images/gossip/home-sf.jpg);"></div>
    <div class="group_overlay"></div>
    <div class="group_name">San Francisco</div>
    <div class="group_info">
        <div class="row stats">
<div class="stat">68 friends</div>            <div class="stat">7,201 members</div>
            <div class="stat">529 posts</div>
        </div>
        <div class="row tags"><div class="tag">local</div><div class="tag">technology</div></div>
        <div class="row about">Local news and gossip</div>
    </div>
</a>
</div>                    <div id="gm" class="flip_container"><a href='/g/'  class="group" data-group_id="">
    <div class="group_photo" style="background-image:url(https://s.mlv-cdn.com/gossip/de054a2ede90d3ff261e801eff54c4c5);"></div>
    <div class="group_overlay"></div>
    <div class="group_name">Politics</div>
    <div class="group_info">
        <div class="row stats">
<div class="stat">74 friends</div>            <div class="stat">19,181 members</div>
            <div class="stat">843 posts</div>
        </div>
        <div class="row tags"><div class="tag">politics</div></div>
        <div class="row about">Everything that happens in the world of politics</div>
    </div>
</a>
</div>
                    <div id="gt"><a href='/g/'  class="group" data-group_id="">
    <div class="group_photo" style="background-image:url(https://s.mlv-cdn.com/gossip/de054a2ede90d3ff261e801eff54c4c5);"></div>
    <div class="group_overlay"></div>
    <div class="group_name">Politics</div>
    <div class="group_info">
        <div class="row stats">
<div class="stat">74 friends</div>            <div class="stat">19,181 members</div>
            <div class="stat">843 posts</div>
        </div>
        <div class="row tags"><div class="tag">politics</div></div>
        <div class="row about">Everything that happens in the world of politics</div>
    </div>
</a>
</div>
                </div>
                <div class="app_buttons">    <a class='app_download_button floatleft' href='https://itunes.apple.com/us/app/candid-speak-your-mind-freely/id991032122?ls=1&amp;mt=8'>
        <img src='/images/gossip/download_ios.png'>
    </a>
    <a class='app_download_button floatright' href='https://play.google.com/store/apps/details?id=com.becandid.candid'>
        <img src='/images/gossip/download_android.png'>
    </a>

</div>
            </div>
        </div
        ><div id="page_2" class="slider_page">
            <div class="slider_contents">
                <h1>Where authentic conversations happen</h1>
                <div class="animation">
                    <div id="post" class='flip_container'><div id='post_' class="post  " data-group_id="" data-post_id="" style=" " >

    <div class="post_contents" style="background-color:#e5ae38; ">
        <div class="post_info">
            <a href='/g/'><div class="group_name" style="color:#e5ae38">Politics</div></a>
<div class="user_post_info">
    <div class="icon #e5ae38"
      style="background: linear-gradient(rgba(229,174,56,0.3), rgba(229,174,56,0.3)), url('/images/gossip/animals/wolf.png');"></div>
    <div class="user_info">
        <div class="name" >CalmWolf</div>
        <div class="time">
1m        </div>
        <div class="clear"></div>
    </div>
</div>

        </div>

        <div class="post_contents_inner text">
                <div class="caption">Who do you think will win the presidential election this year?</div>

        </div>

        <div class="post_actions">
            <div class="action like_post mobile_upsell "><div class="action_icon" ><img class="user_action_button" src="/images/gossip/sprites/all/heart_action.png"/></div><div class="action_text">8</div></div>
            <div class="action dislike_post mobile_upsell "><div class="action_icon"><img class="user_action_button" src="/images/gossip/sprites/all/heartbroken_action.png"/></div><div class="action_text">2</div></div>
            <div class="action comment_post mobile_upsell">
                <div class="action_icon"><img class="user_action_button" src="/images/gossip/sprites/all/comment_action.png"/></div><div class="action_text">16</div>
            </div>
            <div class="action share_post share_upsell"
                data-share_url=""
                data-fb_appid="996059910461168"
                >
                <div class="action_icon"><img class="user_action_button" src="/images/gossip/sprites/all/share_action.png"/></div><div class="action_text">Share</div>
            </div>
            <div class="clear"></div>


        </div>
    </div>

    <div class="post_comments scroll_container ">
        <div class="">
<div class="post_comment">
<div class="user_post_info">
    <div class="icon #226141"
      style="background: linear-gradient(rgba(34,97,65,0.3), rgba(34,97,65,0.3)), url('/images/gossip/animals/urchin.png');"></div>
    <div class="user_info">
        <div class="name" style="color: #226141">NoseyUrchin</div>
        <div class="time">
5m        </div>
        <div class="clear"></div>
    </div>
</div>


    <div class="caption">
            Election fraud is so cool. Get with the program Bernie fans. Resistance is futile
    </div>
</div>
<div class="post_comment">
<div class="user_post_info">
    <div class="icon #96bd6a"
      style="background: linear-gradient(rgba(150,189,106,0.3), rgba(150,189,106,0.3)), url('/images/gossip/animals/bear.png');"></div>
    <div class="user_info">
        <div class="name" style="color: #96bd6a">GroundedBear</div>
        <div class="time">
2m        </div>
        <div class="clear"></div>
    </div>
</div>


    <div class="caption">
            @NoseyUrchin There is no fraud. Learn to loose entitled millenials.
    </div>
</div>
<div class="post_comment">
<div class="user_post_info">
    <div class="icon #4d67c5"
      style="background: linear-gradient(rgba(77,103,197,0.3), rgba(77,103,197,0.3)), url('/images/gossip/animals/kangaroo.png');"></div>
    <div class="user_info">
        <div class="name" style="color: #4d67c5">HealthyKangaroo</div>
        <div class="time">
1m        </div>
        <div class="clear"></div>
    </div>
</div>


    <div class="caption">
            Regardless of who wins, can you see either candidate having two term presidencies?
    </div>
</div>
        </div>
        <div class="scroll_top"></div>
        <div class="scroll_bottom"></div>
    </div>


</div>
</div>
                </div>
                <div class="app_buttons">    <a class='app_download_button floatleft' href='https://itunes.apple.com/us/app/candid-speak-your-mind-freely/id991032122?ls=1&amp;mt=8'>
        <img src='/images/gossip/download_ios.png'>
    </a>
    <a class='app_download_button floatright' href='https://play.google.com/store/apps/details?id=com.becandid.candid'>
        <img src='/images/gossip/download_android.png'>
    </a>

</div>
            </div>
        </div
        ><div id="page_3" class="slider_page">
            <div class="slider_contents">
                <div class="col">
                    <div class="phone"><img src='/images/gossip/Android2.png' /></div>
                </div>
                <div class="col">
                    <h1><br/>Be yourself on Candid</h1>
                    <h2>Are you a socializer, a hater, or an all star? Let our AI system uncover your personality. Uncover how you're really perceived.</h2>
                    <div class="animation">
<div class="badge">
    <img class="badge_icon" src="/images/gossip/badges/socializer.png" />
    <div class="badge_text">Socializer</div>
    <div class="badge_desc">You put yourself out there. You have an opinion and aren&#39;t afraid to share it.</div>
</div>
<div class="badge">
    <img class="badge_icon" src="/images/gossip/badges/all-star.png" />
    <div class="badge_text">All Star</div>
    <div class="badge_desc">You&#39;re the lifeblood of the community. You contribute, interact and engage like no one else.</div>
</div>
<div class="badge">
    <img class="badge_icon" src="/images/gossip/badges/explorer.png" />
    <div class="badge_text">Explorer</div>
    <div class="badge_desc">You&#39;re a curious soul. The new and unfamiliar intrigue you.</div>
</div>
<div class="badge">
    <img class="badge_icon" src="/images/gossip/badges/gossip.png" />
    <div class="badge_text">Gossip</div>
    <div class="badge_desc">If there&#39;s a juicy story to be told, you&#39;re here to tell it.</div>
</div>
<div class="badge">
    <img class="badge_icon" src="/images/gossip/badges/newbie.png" />
    <div class="badge_text">Newbie</div>
    <div class="badge_desc">You&#39;re a newcomer to the Candid community and the possibilities are endless.</div>
</div>
<div class="badge">
    <img class="badge_icon" src="/images/gossip/badges/influencer.png" />
    <div class="badge_text">Influencer</div>
    <div class="badge_desc">When you speak, people listen. You get others interested in any given topic.</div>
</div>
<div class="badge">
    <img class="badge_icon" src="/images/gossip/badges/positive.png" />
    <div class="badge_text">Positive</div>
    <div class="badge_desc">You bring an optimistic, can-do attitude to the table and refuse to let the haters get to you.</div>
</div>
<div class="badge">
    <img class="badge_icon" src="/images/gossip/badges/giver.png" />
    <div class="badge_text">Giver</div>
    <div class="badge_desc">A generous spirit, you support others in the community without expectation of reward.</div>
</div>
<div class="badge">
    <img class="badge_icon" src="/images/gossip/badges/hater.png" />
    <div class="badge_text">Hater</div>
    <div class="badge_desc">You get your kicks by tearing others down. You prefer tossing out insults to offering solutions.</div>
</div>
                    </div>
                    <div class="app_buttons">    <a class='app_download_button floatleft' href='https://itunes.apple.com/us/app/candid-speak-your-mind-freely/id991032122?ls=1&amp;mt=8'>
        <img src='/images/gossip/download_ios.png'>
    </a>
    <a class='app_download_button floatright' href='https://play.google.com/store/apps/details?id=com.becandid.candid'>
        <img src='/images/gossip/download_android.png'>
    </a>

</div>
                </div>
            </div>
        </div
        ><div id="page_4" class="slider_page">
            <div class="slider_contents">
                <h1>Fully Anonymous</h1>
                <h2>Users are never identified. Get Candid Now.</h2>
                <div class="animation">
                    <div class="ring one"></div>
                    <div class="ring two"></div>
                    <div class="ring three"></div>
                    <div class="ring four"></div>
                    <div class="ring five"></div>
                    <div class="ring six"></div>
                    <img class="security" src='/images/gossip/Security.png' />
                </div>
                <div class="app_buttons">    <a class='app_download_button floatleft' href='https://itunes.apple.com/us/app/candid-speak-your-mind-freely/id991032122?ls=1&amp;mt=8'>
        <img src='/images/gossip/download_ios.png'>
    </a>
    <a class='app_download_button floatright' href='https://play.google.com/store/apps/details?id=com.becandid.candid'>
        <img src='/images/gossip/download_android.png'>
    </a>

</div>
            </div>
        </div>
    </div>

    <div class="slider_action right"><div class="bg"></div><div class="img">&rsaquo;</div></div>
    <div class="slider_action left" style="display:hidden"><div class="bg"></div><div class="img">&lsaquo;</div></div>

    <div class="slider_steps">
        <div class="active slider_dot"></div>
        <div class="slider_dot"></div>
        <div class="slider_dot"></div>
        <div class="slider_dot"></div>
        <div class="slider_dot"></div>
    </div>
    <div class="clear"></div>
</div>


        </div>

        <div id="footer" class="   fixed ">
            <div class="main_content">
                <a href='/terms'><div class="tab">Terms of Service</div></a>
                <span>&nbsp;|&nbsp;</span>
                <a href='/privacy'><div class"tab">Privacy Policy</div></a>
                <span>&nbsp;|&nbsp;</span>
                <a href='/help'><div class="tab">Help</div></a>
            </div>
        </div>
        <div id="dialog" class="dialog_wrapper"></div>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>


        <script type="text/javascript"><!--
            var pass_to_js = {"internal_only": false, "encoded_user_id": "vBQ7WkD9MFZ", "user_id": -14653, "js_url": "/s/714a16a3d7afd8f7461325bb5c45e004/loggedout_react.js", "css_url": "/s/3e2562f6e73ee778c99052687eeda590/loggedout_react.css"};
          //-->
        </script>

        <script src="/s/714a16a3d7afd8f7461325bb5c45e004/loggedout_react.js" type="text/javascript"></script>
    </body>
</html>
